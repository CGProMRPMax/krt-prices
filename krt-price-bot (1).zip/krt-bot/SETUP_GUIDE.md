# 🤖 Kulathinal Rubber Price Bot — Setup Guide

This bot automatically fetches rubber prices from rubberboard.gov.in
every morning at 7:00 AM and updates your website. Completely FREE.

---

## How It Works

```
Every morning 7 AM
      ↓
GitHub Bot wakes up (free cloud computer)
      ↓
Visits rubberboard.gov.in → reads RSS4, RSS5, ISNR20, Latex prices
      ↓
Saves prices to prices/prices.json
      ↓
Your website (kulathinal.com) reads the JSON → updates ticker automatically
```

---

## One-Time Setup (15 minutes, completely free)

### Step 1 — Create a free GitHub account
1. Go to https://github.com
2. Click "Sign Up" → use your email george.kjp@gmail.com
3. Choose the FREE plan

### Step 2 — Create a new repository
1. Click the "+" button → "New repository"
2. Name it exactly: **krt-prices**
3. Set it to **Public**
4. Click "Create repository"

### Step 3 — Upload the files
Upload these files from this zip to your repository:
- `scraper/fetch_prices.py`
- `scraper/requirements.txt`
- `.github/workflows/price-bot.yml`
- `prices/prices.json`

### Step 4 — Update your website
In your `index.html`, find this line:
```
const PRICES_JSON_URL = 'https://raw.githubusercontent.com/YOUR_GITHUB_USERNAME/krt-prices/main/prices/prices.json';
```
Replace `YOUR_GITHUB_USERNAME` with your actual GitHub username.

### Step 5 — Upload index.html to Hostinger
Upload the updated index.html to Hostinger as usual (replace index.html in public_html).

### Step 6 — Enable GitHub Actions
1. In your GitHub repository, click the "Actions" tab
2. Click "Enable Actions"
3. Click "Run workflow" to test it immediately

---

## That's It! 🎉

From now on, every morning Mon–Sat at 7:00 AM, the bot will:
1. Wake up on GitHub's free cloud servers
2. Visit rubberboard.gov.in
3. Scrape RSS4, RSS5, ISNR20 and Latex 60% prices
4. Save them to prices.json
5. Your website reads the fresh data automatically

---

## Manual Backup
If the bot ever misses a day (rare), the "✎ Update Prices" button
on the website lets you enter prices manually.

---

## Bot Schedule
- Runs: Monday to Saturday
- Time: 7:00 AM IST
- Sundays: Off (Rubber Board is closed)

---

## Support
Website: www.kulathinal.com
Phone: +91 94004 15649
