"""
Kulathinal Rubber Traders — Rubber Price Bot
Fetches daily rubber prices from rubberboard.gov.in
and saves to prices.json for the website to read.
Runs every morning via GitHub Actions (free, automatic).
"""

import requests
from bs4 import BeautifulSoup
import json
import os
from datetime import datetime, timezone

# ── CONFIG ──
RUBBER_BOARD_URL = "https://rubberboard.gov.in/public"
OUTPUT_FILE = "prices/prices.json"

# Grade names to look for on the Rubber Board page
GRADES = {
    "RSS4":       "rss4",
    "RSS5":       "rss5",
    "ISNR20":     "isnr20",
    "Latex(60%)": "latex60",
}

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-US,en;q=0.9",
}


def fetch_prices():
    """Scrape rubber prices from Rubber Board website."""
    print(f"[{datetime.now()}] Fetching prices from Rubber Board...")

    try:
        response = requests.get(RUBBER_BOARD_URL, headers=HEADERS, timeout=30)
        response.raise_for_status()
    except requests.RequestException as e:
        print(f"ERROR: Could not fetch page — {e}")
        return None

    soup = BeautifulSoup(response.text, "html.parser")

    # Find the domestic market price table
    # The table has headers like "Kottayam", "Kochi", "Agartala"
    prices_found = {}
    tables = soup.find_all("table")

    for table in tables:
        text = table.get_text()
        if "Kottayam" in text and "RSS" in text:
            rows = table.find_all("tr")
            for row in rows:
                cells = row.find_all(["td", "th"])
                if len(cells) >= 2:
                    grade_cell = cells[0].get_text(strip=True)
                    # Match grade names
                    for grade_label, grade_key in GRADES.items():
                        # Handle variations like "Latex(60%)" or "Latex (60%)"
                        label_clean = grade_label.replace(" ", "").replace("(", "").replace(")", "").lower()
                        cell_clean = grade_cell.replace(" ", "").replace("(", "").replace(")", "").lower()
                        if label_clean in cell_clean or cell_clean in label_clean:
                            # Try to get Kottayam price (first price column)
                            for cell in cells[1:]:
                                raw = cell.get_text(strip=True)
                                # Remove arrows/symbols, keep numbers and dots
                                cleaned = ""
                                for ch in raw:
                                    if ch.isdigit() or ch == ".":
                                        cleaned += ch
                                if cleaned and float(cleaned) > 100:
                                    prices_found[grade_key] = float(cleaned)
                                    print(f"  Found {grade_label}: ₹{cleaned} per 100kg")
                                    break
            break  # Found the right table

    return prices_found if prices_found else None


def load_previous_prices():
    """Load yesterday's prices for change calculation."""
    if os.path.exists(OUTPUT_FILE):
        try:
            with open(OUTPUT_FILE, "r") as f:
                data = json.load(f)
                return data.get("prices", {})
        except Exception:
            pass
    return {}


def build_output(prices, prev_prices):
    """Build the final JSON output for the website."""
    now = datetime.now(timezone.utc)

    grades = {}
    for key, val_100kg in prices.items():
        per_kg = round(val_100kg / 100, 2)
        prev_val = prev_prices.get(key, val_100kg)

        if val_100kg > prev_val:
            change = "up"
            diff = round(val_100kg - prev_val, 1)
        elif val_100kg < prev_val:
            change = "down"
            diff = round(prev_val - val_100kg, 1)
        else:
            change = "flat"
            diff = 0.0

        grades[key] = {
            "per_kg":    per_kg,
            "per_100kg": val_100kg,
            "change":    change,
            "diff":      diff,
        }

    return {
        "updated_at":   now.strftime("%d %b %Y"),
        "updated_time": now.strftime("%I:%M %p IST"),
        "market":       "Kottayam",
        "source":       "Rubber Board, Govt. of India",
        "source_url":   "https://rubberboard.gov.in/public",
        "prices":       grades,
    }


def save_output(data):
    """Save JSON to the prices folder."""
    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)
    with open(OUTPUT_FILE, "w") as f:
        json.dump(data, f, indent=2)
    print(f"[OK] Prices saved to {OUTPUT_FILE}")
    print(json.dumps(data, indent=2))


def main():
    prev_prices_raw = load_previous_prices()
    # Extract raw per_100kg values from previous
    prev_100kg = {k: v.get("per_100kg", 0) for k, v in prev_prices_raw.items()}

    prices = fetch_prices()

    if not prices:
        print("WARNING: Could not scrape prices. Using fallback defaults.")
        # Fallback: keep yesterday's prices, just update date
        prices = prev_100kg if prev_100kg else {
            "rss4":    21700.0,
            "rss5":    21200.0,
            "isnr20":  18600.0,
            "latex60": 15110.0,
        }

    output = build_output(prices, prev_100kg)
    save_output(output)
    print(f"\n[DONE] Bot completed at {datetime.now()}")


if __name__ == "__main__":
    main()
